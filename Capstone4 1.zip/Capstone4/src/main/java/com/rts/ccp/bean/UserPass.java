package com.rts.ccp.bean;

public class UserPass {
	
	private Long userId;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public UserPass(Long userId) {
		super();
		this.userId = userId;
	}

	public UserPass() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
